import React from 'react'

import { FormRegistroAula } from './FormRegistroAula'

import './estilosRegistroAula.css'

export const RegistroAulasScreen = () => {
    
    return(   
            <FormRegistroAula/>
    )

}
