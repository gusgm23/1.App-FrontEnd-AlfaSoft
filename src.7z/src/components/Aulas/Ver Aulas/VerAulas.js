import React from 'react'

export const VerAulas = () => {
  return (
    <div>VerAulas</div>
  )
}
