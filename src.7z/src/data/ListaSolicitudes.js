const ListaSolicitudes = [

    {
        id: 1,
        materia: 'Algebra II',
        grp_materia: '6A',
        aula: '690B',
        hr_inicio: '08:15',
        hr_fin: '09:45',
        fecha_sol: '24-04-2022'
    },
    {
        id: 2,
        materia: 'CalculoIII',
        grp_materia: '6A',
        aula: '692C',
        hr_inicio: '11:15',
        hr_fin: '12:45',
        fecha_sol: '24-04-2022'
    },
    {
        id: 3,
        materia: 'Introduccion a la Programacion',
        grp_materia: '2A',
        aula: '691C',
        hr_inicio: '15:45',
        hr_fin: '17:15',
        fecha_sol: '24-04-2022'
    },
    {
        id: 4,
        materia: 'Fisica',
        grp_materia: '1A',
        aula: '670',
        hr_inicio: '14:15',
        hr_fin: '15:45',
        fecha_sol: '22-04-2022'
    },
    {
        id: 5,
        materia: 'Elementos de Programacion',
        grp_materia: '8A',
        aula: '690',
        hr_inicio: '17:15',
        hr_fin: '18:45',
        fecha_sol: '21-04-2022'
    }
]



export default ListaSolicitudes