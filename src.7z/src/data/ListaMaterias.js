const ListaMaterias = [{
    id: 1,
    codSis: 201702903,
    materia: 'Algebra II',
    grupo: '6A'
},
{
    id: 2,
    codSis: 201602905,
    materia: 'Algebra I',
    grupo: '2'
},
{
    id: 3,
    codSis: 201602903,
    materia: 'Fisica II',
    grupo: '1'
},
{
    id: 4,
    codSis: 201602903,
    materia: 'calculo II',
    grupo: '2'
},
{
    id: 5,
    codSis: 201602903,
    materia: 'Mercadotécnia',
    grupo: '2'
},
{
    id: 6,
    codSis: 201602903,
    materia: 'Ecuaciones diferenciales',
    grupo: '3'
},
{
    id: 7,
    codSis: 201602903,
    materia: 'Circuitos electricos',
    grupo: '1'
},
{
    id: 8,
    codSis: 201602903,
    materia: 'Taller de programación',
    grupo: '2'
},
]

export default ListaMaterias