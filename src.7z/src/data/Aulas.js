const Aulas = [{
    id: 1,
    aula: '690C',
    capacidad: 30,
    estado: 'libre'
},
{
    id:2,
    aula: '660',
    capacidad: 30,
    estado: 'libre'
},
{
    id:3,
    aula: '692h',
    capacidad: 30,
    estado: 'libre'
},
{
    id:4,
    aula: 'Auditorio',
    capacidad: 150,
    estado: 'libre'
},
{
    id:5,
    aula: '693C',
    capacidad: 60,
    estado: 'libre'
},
{
    id:6,
    aula: '693B',
    capacidad: 60,
    estado: 'libre'
},
{
    id:7,
    aula: '693A',
    capacidad: 60,
    estado: 'libre'
},
{
    id:8,
    aula: '655',
    capacidad: 25,
    estado: 'libre'
},
{
    id:9,
    aula: '617C',
    capacidad: 35,
    estado: 'libre'
},
{
    id:10,
    aula: '624',
    capacidad: 80,
    estado: 'libre'
},
{
    id:11,
    aula: '693B',
    capacidad: 60,
    estado: 'libre'
},
{
    id:12,
    aula: '693A',
    capacidad: 60,
    estado: 'libre'
},
{
    id:13,
    aula: '655',
    capacidad: 25,
    estado: 'libre'
},
{
    id:14,
    aula: '617C',
    capacidad: 35,
    estado: 'libre'
},
{
    id:15,
    aula: '624',
    capacidad: 80,
    estado: 'libre'
}
]

export default Aulas;