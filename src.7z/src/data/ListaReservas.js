export const listaReservas = [
    {
        id: 1,
        fechaReserva: "2022-05-04",
        horaInicioReserva: "12:45",
        horaFinalReserva: "14:15",
        aula_id: 1
    },
    {
        id: 2,
        fechaReserva: "2022-05-04",
        horaInicioReserva: "12:45",
        horaFinalReserva: "14:15",
        aula_id: 2
    }
]