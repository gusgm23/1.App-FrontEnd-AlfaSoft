const ListaGrupos = [{
    id: 1,
    grupo: 1
},
{
    id: 2,
    grupo: 2
},
{
    id: 3,
    grupo: 3
},
{
    id: 4,
    grupo: 4
},
{
    id: 5,
    grupo: 5
},
{
    id: 6,
    grupo: 6
},
{
    id: 7,
    grupo: 7
},
{
    id: 8,
    grupo: 8
},]

export default ListaGrupos