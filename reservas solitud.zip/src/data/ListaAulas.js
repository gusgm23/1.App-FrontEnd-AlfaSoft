export const listaAulas = [
    {
        id: 1,
        nombreAula: "692a",
        capacidadAula: "90",
        estadoAula: "Libre",
        habilitacionAula: "Habilitado",
        solicitud_id: 1
    },
    {
        id: 2,
        nombreAula: "655",
        capacidadAula: "30",
        estadoAula: "Libre",
        habilitacionAula: "Habilitado",
        solicitud_id: 1
    },
    {
        id: 3,
        nombreAula: "690A",
        capacidadAula: "90",
        estadoAula: "Ocupado",
        habilitacionAula: "Inhabilitado",
        solicitud_id: 2
    }
]