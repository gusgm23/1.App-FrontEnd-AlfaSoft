import React from 'react'

export const HistorialSolicitudes = () => {
    return (
        <div>HistorialSolicitudes</div>
    )
}
