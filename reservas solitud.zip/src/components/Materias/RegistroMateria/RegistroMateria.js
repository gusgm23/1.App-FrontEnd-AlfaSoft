import React from 'react'

import { FormRegistroMateria } from './FormRegistroMateria';

import './estilos-form-reg-materia.css';

export const RegistroMateria = () => {
    
    return (
        <div className='componente'>
            
            <FormRegistroMateria />

        </div>
    )
    
}
