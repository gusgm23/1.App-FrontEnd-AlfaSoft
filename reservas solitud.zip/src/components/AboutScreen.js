import React from 'react'

export const AboutScreen = () => {
    return (
        <div>
            <h1>AboutScreen</h1>
            <hr/>
            <p>
                Acerca de AlfaSoft S.R.L.
            </p>
        </div>
    )
}
